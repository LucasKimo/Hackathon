export default function Login() {
  return (
    <>
      <h2>Login Page</h2>
    </>
  )
}